//
//  MyLibraryV.h
//  MyLibraryV
//
//  Created by Gabriel Zempoalteca Garrido on 04/01/24.
//

#import <Foundation/Foundation.h>

//! Project version number for MyLibraryV.
FOUNDATION_EXPORT double MyLibraryVVersionNumber;

//! Project version string for MyLibraryV.
FOUNDATION_EXPORT const unsigned char MyLibraryVVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyLibraryV/PublicHeader.h>


